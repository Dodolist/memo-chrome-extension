# 메모짱
구글 계정 간의 동기화가 가능한 크롬 확장 프로그램입니다.

# memo-chrome-extension
When you need a memo while using Chrome Press "Command + M"


## [Free Download](https://chrome.google.com/webstore/detail/memozzang/nnocokeccpdhijhmjekelnhmmjimplco?hl=ko&authuser=0)
