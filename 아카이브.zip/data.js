// memoList가 보여지는지
var showMemoList = false;

// topbar 보여지는지
var showTopbar = false;
